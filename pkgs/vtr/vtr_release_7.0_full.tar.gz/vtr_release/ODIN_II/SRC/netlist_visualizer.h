#include "types.h"

void graphVizOutputNetlist(char* path, char* name, short marker_value, netlist_t *netlist); 
void graphVizOutputCombinationalNet(char* path, char* name, short marker_value, nnode_t *current_node);
