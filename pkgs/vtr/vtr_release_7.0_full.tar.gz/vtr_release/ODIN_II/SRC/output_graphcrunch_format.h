#include "types.h"

void graphcrunch_output(char* path, char* name, short marker_value, netlist_t *netlist); 
