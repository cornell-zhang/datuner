// PROTOTYPES
void output_top(netlist_t *netlist);
