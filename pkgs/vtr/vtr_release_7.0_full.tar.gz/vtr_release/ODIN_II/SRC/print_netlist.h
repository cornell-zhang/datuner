
void print_netlist_for_checking (netlist_t *netlist,char *name);
