
void error_message(short error_type, int line_number, int file, char *message, ...);
void warning_message(short error_type, int line_number, int file, char *message, ...);
