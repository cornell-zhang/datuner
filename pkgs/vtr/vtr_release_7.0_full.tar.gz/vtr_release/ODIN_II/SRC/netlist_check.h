
void check_netlist(netlist_t *netlist);
void levelize_and_check_for_combinational_loop_and_liveness(short ast_based, netlist_t *netlist);
